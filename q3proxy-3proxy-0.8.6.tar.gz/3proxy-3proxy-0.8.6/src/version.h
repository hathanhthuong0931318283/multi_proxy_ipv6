#ifndef VERSION
#define VERSION "3proxy-0.9.3"
#endif
#ifndef BUILDDATE
#define BUILDDATE ""
#endif
#define MAJOR3PROXY 0
#define SUBMAJOR3PROXY 9
#define MINOR3PROXY 3
#define SUBMINOR3PROXY 0
#define RELEASE3PROXY "3proxy-0.9.3(" BUILDDATE ")\0"
#define YEAR3PROXY "2020"
